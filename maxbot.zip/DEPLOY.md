# 🚀 Пошаговая инструкция по развёртыванию на сервере
## Проект «Лига Помощников» (Мессенджер MAX)

Данная инструкция описывает полный процесс развёртывания бота и WebApp на боевом VPS-сервере с привязкой домена **`itcubefor.ru`**, готовым SSL-сертификатом и Nginx.

---

## 📋 Исходные данные вашего проекта

* **Домен:** `https://itcubefor.ru/`
* **Токен бота MAX:** `f9LHodD0cOIbnBMzplPQRTINC9XyaH6WONrahIiFxz56_7JWB2imZe0VhnV5nQt-pYd-Y8A4S3kcifXXVLZ7`
* **Юзернейм бота:** `ideya_fiks_59_bot` ([https://max.ru/ideya_fiks_59_bot](https://max.ru/ideya_fiks_59_bot))
* **Внутренний порт приложения:** `8000`

---

## ШАГ 1. Подключение к серверу по SSH

Откройте терминал (PowerShell на Windows или bash/zsh на Mac/Linux) и подключитесь к вашему серверу:

```bash
ssh root@IP_ВАШЕГО_СЕРВЕРА
```
*(Замените `IP_ВАШЕГО_СЕРВЕРА` на реальный IP-адрес арендованного сервера).*

---

## ШАГ 2. Проверка и установка Docker

Убедитесь, что на сервере установлены Docker и плагин Docker Compose.

1. Проверьте версии:
```bash
docker --version
docker compose version
```

2. Если Docker ещё не установлен, выполните установку:
```bash
apt update
apt install -y docker.io docker-compose-plugin git
systemctl enable --now docker
```

---

## ШАГ 3. Клонирование проекта с GitHub

1. Перейдите в каталог для размещения сервисов (например, `/opt`):
```bash
cd /opt
```

2. Склонируйте ваш репозиторий с GitHub:
```bash
git clone https://github.com/ВАШ_АККАУНТ/maxbot.git
cd maxbot
```

---

## ШАГ 4. Создание секретного файла `.env` на сервере

Так как файл `.env` не хранится на GitHub (он добавлен в `.gitignore` для безопасности), создайте его прямо на сервере:

```bash
nano .env
```

Вставьте в файл следующие боевые настройки:

```ini
BOT_TOKEN=f9LHodD0cOIbnBMzplPQRTINC9XyaH6WONrahIiFxz56_7JWB2imZe0VhnV5nQt-pYd-Y8A4S3kcifXXVLZ7
BASE_URL=https://itcubefor.ru
BOT_USERNAME=ideya_fiks_59_bot
SECRET_TEACHER_CODE=учитель11
HOST=0.0.0.0
PORT=8000
```

*Нажмите `Ctrl + O`, затем `Enter` для сохранения, и `Ctrl + X` для выхода из редактора.*

---

## ШАГ 5. Настройка Nginx и SSL

Ваш Nginx должен принимать запросы по HTTPS с домена `itcubefor.ru` и перенаправлять их в Docker-контейнер на порт `8000`.

1. Откройте конфигурационный файл вашего сайта:
```bash
nano /etc/nginx/sites-available/itcubefor.ru
```
*(или `/etc/nginx/conf.d/default.conf` в зависимости от структуры вашей ОС)*

2. Убедитесь, что секция `server` для 443 порта настроена следующим образом:

```nginx
server {
    listen 80;
    server_name itcubefor.ru www.itcubefor.ru;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name itcubefor.ru www.itcubefor.ru;

    # Пути к вашим уже установленным SSL-сертификатам
    ssl_certificate /etc/letsencrypt/live/itcubefor.ru/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/itcubefor.ru/privkey.pem;

    # Оптимизация SSL
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

3. Проверьте конфигурацию Nginx на отсутствие синтаксических ошибок:
```bash
nginx -t
```
Должен появиться ответ: `syntax is ok / test is successful`.

4. Примените настройки:
```bash
systemctl reload nginx
```

---

## ШАГ 6. Запуск проекта через Docker

1. Находясь в папке `/opt/maxbot`, запустите сборку и старт контейнера:
```bash
docker compose up -d --build
```

2. Проверьте статус запущенного контейнера:
```bash
docker compose ps
```
Контейнер `liga_pomoshnikov_bot` должен иметь статус `Up (healthy)` или `Up`.

3. Проверьте логи запуска:
```bash
docker compose logs -f
```
В логах вы увидите:
* `Инициализация базы данных SQLite...`
* `База данных готова к работе.`
* `Бот MAX запущен в фоновом режиме.`
* `Application startup complete. Uvicorn running on http://0.0.0.0:8000`

*(Для выхода из просмотра логов нажмите `Ctrl + C`).*

---

## ШАГ 7. Проверка доступности в браузере

1. Откройте в любом браузере: **`https://itcubefor.ru/`**
2. Вы увидите главную страницу WebApp «Лига Помощников» с профилем, рейтингом, достижениями и лавкой наград.
3. Проверьте Swagger-документацию API: **`https://itcubefor.ru/docs`**

---

## ШАГ 8. Настройка в кабинете разработчика MAX (dev.max.ru)

1. Зайдите на платформу разработчиков MAX или в чат-бот хакатона.
2. Откройте настройки вашего чат-бота **`ideya_fiks_59_bot`**.
3. В разделе **Mini App / WebApp** укажите URL-адрес стартовой страницы:
   ```
   https://itcubefor.ru/
   ```
4. Сохраните изменения. Теперь при нажатии на кнопку в боте внутри мессенджера MAX будет сразу открываться ваш WebApp!

---

## 🔄 Как обновлять проект при изменении кода

Если вы внесли изменения в репозиторий на GitHub, на сервере достаточно выполнить:

```bash
cd /opt/maxbot
git pull
docker compose up -d --build
```
База данных `database.db` сохраняется в примонтированном томе и **не потеряет** данные пользователей при перезапуске!

